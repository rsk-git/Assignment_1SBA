Project Overview:
Community garden: A small community of around 30 families in a small town of Berkshire county, Massachusetts started a community garden project in 2024. These families are trying to grow own seasonal fruits and vegetables which will be accessible for the comunity members.

Features:

Heading: The heading of the webiste is "Happy Garden". Below the heading you can hover over and click on produce page or contact page for more information and it takes to the respective pages.

Registration Form: This form is found on home page, to be filled by the community members in order to get access to the community garden.The registration form has three required fields, first name, last name and email.  These fields should be filled and click on submit button in order to get submitted.

Forums: Work in Progress.  The community members are still working on forums and should be running up shortly.

Training: Work in Progress.  The community members are working a sustainable gardening training program especially for beginners in this field.
Blogs: Currently blog section is to be built as we progress by the end of the year.
Produce: The produce section will maintain the available vegetable and fruits for the members.

Event calendar: The calendar is found on the home page for the season is up and running for the current year and will be updated periodically.  If any changes to the schedule will be notified to the members.

Contact: A contact us form is available on contact us page, is provided to answer any kind of questions about the community garden. The contact us form has required fields to be filled with applicant's name, email and message.  Then click on the send message button for submission.  A phone number and email is also provided for the timely assistance. Click on email link and it takes directly to message us.By clicking on phone number you can reach us and talk to a customer service representative.

